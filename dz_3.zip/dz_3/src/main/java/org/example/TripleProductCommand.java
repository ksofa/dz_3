package org.example;

import java.util.Map;

public class TripleProductCommand implements Command {
    private final Map<String, Vector3D> vectors;

    public TripleProductCommand(Map<String, Vector3D> vectors) {
        this.vectors = vectors;
    }

    @Override
    public String execute(String[] args) {
        try {
            Vector3D v1 = vectors.get(args[1]);
            Vector3D v2 = vectors.get(args[2]);
            Vector3D v3 = vectors.get(args[3]);

            double tripleProduct = Vector3D.dotProduct(v1, Vector3D.crossProduct(v2, v3));
            return "Triple product: " + tripleProduct;
        } catch (NullPointerException e) {
            return "Error: One of the vectors does not exist.";
        } catch (IndexOutOfBoundsException e) {
            return "Error: Not enough arguments.";
        }
    }
}
