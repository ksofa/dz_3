package org.example.server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DatabaseConfig {

    @Bean
    public Connection jdbcConnection() throws SQLException {
        // Замените URL, имя пользователя и пароль на ваши значения
        String jdbcURL = "jdbc:h2:mem:testdb";
        String jdbcUsername = "sa";
        String jdbcPassword = "";

        return DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
    }
}
