package org.example.server;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.example.Vector3D;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;



@Repository
public class VectorDao {

    @Autowired
    private Connection jdbcConnection;

    public void addVector(String name, Vector3D vector) throws SQLException {
        try (PreparedStatement ps = jdbcConnection.prepareStatement("INSERT INTO vectors (name, x, y, z) VALUES (?, ?, ?, ?)")) {
            ps.setString(1, name);
            ps.setDouble(2, vector.getX());
            ps.setDouble(3, vector.getY());
            ps.setDouble(4, vector.getZ());
            ps.executeUpdate();
        }
    }

    public Vector3D findByName(String name) throws SQLException {
        try (PreparedStatement ps = jdbcConnection.prepareStatement("SELECT x, y, z FROM vectors WHERE name = ?")) {
            ps.setString(1, name);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Vector3D(name, rs.getDouble("x"), rs.getDouble("y"), rs.getDouble("z"));
            } else {
                return null;
            }
        }
    }

    public Map<String, Vector3D> findAll(int pageSize, int pageNumber) throws SQLException {
        Map<String, Vector3D> vectors = new HashMap<>();
        int offset = pageSize * (pageNumber - 1);

        try (PreparedStatement ps = jdbcConnection.prepareStatement("SELECT name, x, y, z FROM vectors LIMIT ? OFFSET ?")) {
            ps.setInt(1, pageSize);
            ps.setInt(2, offset);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Vector3D vector = new Vector3D(rs.getString("name"), rs.getDouble("x"), rs.getDouble("y"), rs.getDouble("z"));
                vectors.put(rs.getString("name"), vector);
            }
        }

        return vectors;
    }


    public void removeByName(String name) throws SQLException {
        try (PreparedStatement ps = jdbcConnection.prepareStatement("DELETE FROM vectors WHERE name = ?")) {
            ps.setString(1, name);
            ps.executeUpdate();
        }
    }

    public boolean existsByName(String name) throws SQLException {
        try (PreparedStatement ps = jdbcConnection.prepareStatement("SELECT COUNT(*) FROM vectors WHERE name = ?")) {
            ps.setString(1, name);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            } else {
                return false;
            }
        }
    }

    public int countAll() throws SQLException {
        try (PreparedStatement ps = jdbcConnection.prepareStatement("SELECT COUNT(*) FROM vectors")) {
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            } else {
                return 0;
            }
        }
    }
    public void deleteByName(String name) throws SQLException {
        try (PreparedStatement ps = jdbcConnection.prepareStatement("DELETE FROM vectors WHERE name = ?")) {
            ps.setString(1, name);
            ps.executeUpdate();
        }
    }

    public void clearAll() throws SQLException {
        try (PreparedStatement ps = jdbcConnection.prepareStatement("DELETE FROM vectors")) {
            ps.executeUpdate();
        }
    }
}
