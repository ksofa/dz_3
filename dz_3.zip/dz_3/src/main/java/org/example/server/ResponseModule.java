package org.example.server;


import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;

public class ResponseModule {

    public void sendResponse(Socket socket, String response) throws IOException {
        PrintWriter socketWriter = new PrintWriter(socket.getOutputStream(), true);
        socketWriter.println(response);
    }
}
