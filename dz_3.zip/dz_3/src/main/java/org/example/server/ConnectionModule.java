package org.example.server;


import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ConnectionModule implements AutoCloseable {
    private final ServerSocket serverSocket;

    public ConnectionModule(int port) throws IOException {
        this.serverSocket = new ServerSocket(port);
    }

    public Socket acceptConnection() throws IOException {
        return serverSocket.accept();
    }

    @Override
    public void close() throws IOException {
        serverSocket.close();
    }
}
