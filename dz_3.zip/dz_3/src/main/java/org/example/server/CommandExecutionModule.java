package org.example.server;


import org.example.Command;

import java.io.IOException;
import java.util.Map;

public class CommandExecutionModule {
    private final Map<String, Command> commands;

    public CommandExecutionModule(Map<String, Command> commands) {
        this.commands = commands;
    }

    public String executeCommand(String request) throws IOException, ClassNotFoundException {
        String[] parts = request.split(" ");
        Command command = commands.get(parts[0].toLowerCase());
        if (command != null) {
            return command.execute(parts);
        }
        return "Неизвестная команда";
    }
}
