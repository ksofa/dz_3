package org.example.server;

import org.example.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.Socket;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
@SpringBootApplication
@ComponentScan(basePackages = {"org.example.server", "another.package.where.your.beans.are"})
public class ServerApp implements CommandLineRunner {

    private static final int PORT = 8080;

    @Autowired
    private StorageModule storageModule;

    @Autowired
    private FileModule fileModule;

    @Autowired
    private ConnectionModule connectionModule;

    @Autowired
    private CommandExecutionModule commandExecutionModule;

    @Autowired
    private RequestModule requestModule;

    @Autowired
    private ResponseModule responseModule;

    @Autowired
    private ReadCommand readCommand;

    @Bean
    public CommandExecutionModule commandExecutionModule() throws SQLException {
        Map<String, Command> commands = new HashMap<>();
        commands.put("create", new CreateCommand(storageModule.getVectors()));
        commands.put("read", readCommand);
        commands.put("exit", new ExitCommand());
        commands.put("range", new RangeCommand(storageModule.getVectors()));
        commands.put("angle", new AngleCommand(storageModule.getVectors()));
        commands.put("product", new ProductCommand(storageModule.getVectors()));
        commands.put("product triple", new TripleProductCommand(storageModule.getVectors()));

        return new CommandExecutionModule(commands);
    }

    public static void main(String[] args) {
        SpringApplication.run(ServerApp.class, args);
    }

    @Override
    public void run(String[] args) {
        System.out.println("Server started and listening on port " + PORT);

        try {
            Map<String, Vector3D> vectors = (Map<String, Vector3D>) fileModule.loadFromFile(storageModule.getVectors(), "vectors.dat");
            storageModule.getVectors().putAll(vectors);
        } catch (FileNotFoundException e) {
            System.out.println("Starting with an empty vectors database as vectors.dat file is not found.");
        } catch (ClassNotFoundException | IOException | SQLException e) {
            System.out.println("Failed to load vectors from file: " + e.getMessage());
        }

        while (true) {
            try (Socket clientSocket = connectionModule.acceptConnection()) {
                System.out.println("Client connected.");

                while (!clientSocket.isClosed()) {
                    String request = requestModule.readRequest(clientSocket);

                    if (request == null || "exit".equalsIgnoreCase(request)) {
                        clientSocket.close();
                        break;
                    }

                    String response = commandExecutionModule.executeCommand(request);
                    responseModule.sendResponse(clientSocket, response);
                }
            } catch (IOException | ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
