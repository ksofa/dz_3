package org.example.server;

import org.example.Vector3D;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.Map;

@Component
public class StorageModule {

    @Autowired
    private VectorDao vectorDao;

    public void addVector(String name, Vector3D vector) throws SQLException {
        vectorDao.addVector(name, vector);
    }

    public Vector3D getVector(String name) throws SQLException {
        return vectorDao.findByName(name);
    }

    public Map<String, Vector3D> getVectors() throws SQLException {
        int defaultPageSize = 10;
        int defaultPageNumber = 1;
        return vectorDao.findAll(defaultPageSize, defaultPageNumber);
    }



    public void removeVector(String name) throws SQLException {
        vectorDao.removeByName(name);
    }

    public boolean vectorExists(String name) throws SQLException {
        return vectorDao.existsByName(name);
    }

    public int vectorCount() throws SQLException {
        return vectorDao.countAll();
    }

    public void clear() throws SQLException {
        vectorDao.clearAll();
    }
}
