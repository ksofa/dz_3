package org.example;

import java.util.Map;
public class ProductCommand implements Command {
    private final Map<String, Vector3D> vectors;

    public ProductCommand(Map<String, Vector3D> vectors) {
        this.vectors = vectors;
    }

    @Override
    public String execute(String[] args) {
        try {
            if ("dot".equalsIgnoreCase(args[1])) {
                double dotProduct = Vector3D.dotProduct(vectors.get(args[2]), vectors.get(args[3]));
                return "Скалярное произведение: " + dotProduct;
            } else if ("cross".equalsIgnoreCase(args[1])) {
                Vector3D crossProduct = Vector3D.crossProduct(vectors.get(args[2]), vectors.get(args[3]));
                return "Векторное произведение: " + crossProduct;
            } else {
                return "Ошибка: некорректный тип произведения.";
            }
        } catch (NullPointerException e) {
            return "Ошибка: один из векторов с таким именем не существует.";
        } catch (IndexOutOfBoundsException e) {
            return "Ошибка: недостаточно аргументов.";
        }
    }

}