package org.example;

import org.example.server.VectorDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.SQLException;

@Component
public class DeleteCommand implements Command {

    @Autowired
    private VectorDao vectorDao;

    @Override
    public String execute(String[] args) {
        if (args.length < 2) {
            return "Vector name not provided!";
        }

        try {
            vectorDao.deleteByName(args[1]);
            return "Vector deleted successfully!";
        } catch (SQLException e) {
            return "Error deleting vector: " + e.getMessage();
        }
    }
}
