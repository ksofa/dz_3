package org.example;

import java.util.Map;
public class RangeCommand implements Command {
    private final Map<String, Vector3D> vectors;

    public RangeCommand(Map<String, Vector3D> vectors) {
        this.vectors = vectors;
    }

    @Override
    public String execute(String[] args) {
        try {
            return "Длина вектора: " + vectors.get(args[1]).length();
        } catch (NullPointerException e) {
            return "Ошибка: вектор с таким именем не существует.";
        } catch (IndexOutOfBoundsException e) {
            return "Ошибка: недостаточно аргументов.";
        }
    }
}