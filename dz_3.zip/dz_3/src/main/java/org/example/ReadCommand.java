package org.example;

import org.example.server.VectorDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.SQLException;
import java.util.Map;

@Component
public class ReadCommand implements Command {

    @Autowired
    private VectorDao vectorDao;

    @Override
    public String execute(String[] args) {
        if (args.length < 3) {
            return "Insufficient arguments. Expected: pageSize and pageNumber";
        }
        try {
            int pageSize = Integer.parseInt(args[1]);
            int pageNumber = Integer.parseInt(args[2]);
            Map<String, Vector3D> vectors = vectorDao.findAll(pageSize, pageNumber);
            return vectors.toString();
        } catch (NumberFormatException e) {
            return "Invalid arguments. Expected numbers for pageSize and pageNumber.";
        } catch (SQLException e) {
            return "Error reading vectors: " + e.getMessage();
        }
    }
}
