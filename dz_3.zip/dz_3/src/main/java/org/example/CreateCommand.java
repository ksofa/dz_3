package org.example;

import java.util.Map;

public class CreateCommand implements Command {
    private final Map<String, Vector3D> vectors;

    public CreateCommand(Map<String, Vector3D> vectors) {
        this.vectors = vectors;
    }

    @Override
    public String execute(String[] args) {
        if(args.length < 5) {
            return "Ошибка: недостаточно аргументов.";
        }
        try {
            vectors.put(args[1], new Vector3D(args[1], Double.parseDouble(args[2]), Double.parseDouble(args[3]), Double.parseDouble(args[4])));
            return "Вектор " + args[1] + " создан.";
        } catch (NumberFormatException e) {
            return "Ошибка: некорректный формат числа.";
        }
    }
}
